

clear
%close all


figure(21)
clf
figure(22)
clf

name{1}='Texas'; name{2}='Florida'; name{3}='Ohio'; name{4}='Pennsylvania'; name{5}='Wisconsin';
name{6}='Georgia'; name{7}='Indiana';  name{8}='Illinois';

numstates=length(name);


number_clusters=zeros(numstates,1); % how many clusters in dataset, i.e. lines we use
number_schools=zeros(numstates,1); % number of schools appearing in cluster list
num_schools_mult_clusters=zeros(numstates,1); % number of schools with multiple clusters



for j=1:numstates
  
 
  % get cluster data
  T=readtable(strcat('datasets/',name{j},'.xlsx'));
  inds=~isnan(T.Confirmed_Students) & (T.Confirmed_Students~=0);
  clusters=T.Confirmed_Students(inds);
  school_id=strcat(T.School(inds),T.City(inds));
  months=month(T.SourceDate(inds));
  weeks=week(T.SourceDate(inds));
  clust{j}=clusters;
  dates{j}=T.SourceDate(inds);
  
  cluster_list=clust{j};
  
  if j<=4
      figure(21)
      subplot(2,2,j)
  else
      figure(22)
      subplot(2,2,j-4)
  end
  histogram(cluster_list,(0:30),'facecolor',[0.3010 0.7450 0.9330])
  hold on
  title(name{j},'fontname','sansserif','fontsize',20)
  xlabel('cases per cluster','fontname','sansserif','fontsize',15)
  ylabel('count','fontname','sansserif','fontsize',20)
  xlim([0 30])
  
  % make dots for clusters of size 6 or larger
  for clussize=8:30
      num_with_size=sum(cluster_list==clussize);
      yl=ylim;
      scalefact=yl(2)/20;
      plot(clussize*ones(num_with_size),scalefact*(1:num_with_size),'.','markersize',20,'color',[0 0.4470 0.7410])
  end
  
  
%   subplot(4,2,j)
%   histogram(clusters,(0:30))
%   title(name{j})
%   xlabel('cases per cluster')
%   ylabel('count')
%   xlim([0 30])
      
  number_clusters(j)=length(clusters);
 
  unique_school_id=unique(school_id,'stable');
  number_schools(j)=length(unique_school_id);
   
  tbl_month=crosstab(school_id,months);
  tbl_week=crosstab(school_id,weeks);

  num_schools_mult_clusters(j)=sum(sum(tbl_week')>1);
  
  frac_no_transm(j)=sum(clusters==1)/length(clusters);
  
  mean_obs_cluster(j)=mean(clusters);
  
   max_obs_cluster(j)=max(cluster_list);
  
  q3(j)=prctile(cluster_list,75);
  
  median_obs_cluster(j)=median(cluster_list);
  
  index_of_dispersion(j)=var(cluster_list)/mean(cluster_list);
  
  iod_without_index(j)=var(cluster_list-1)/mean(cluster_list-1);
  
end

save jurisdiction_data


% print it out into latex table
for j=1:numstates
     disp(strcat(...
         name{j},' &  ', ...
        num2str(number_clusters(j)),' & ',...
        num2str(number_schools(j)),' & ',...
         num2str(num_schools_mult_clusters(j)),' & ',...      
      num2str(num_schools_mult_clusters(j)/number_schools(j),'%.2f'),' \\'))
end
for j=1:numstates
     disp(strcat(...
         name{j},' &  ', ...     
      num2str(frac_no_transm(j),'%.2f'),' & ',...
       num2str(mean_obs_cluster(j),'%.2f'),' & ',...
        num2str(max_obs_cluster(j)),' & ',...
        num2str(index_of_dispersion(j),'%.2f'),' & ',...
           num2str(iod_without_index(j),'%.2f'),' \\'))
end


figure(21)  
for jjj=1:4
    subplot(2,2,jjj)
    ax = gca;
ax.FontSize = 16; 
end
print -dpng histograms_usa_1

figure(22)  
for jjj=1:4
    subplot(2,2,jjj)
    ax = gca;
ax.FontSize = 16; 
end
print -dpng histograms_usa_2

      
