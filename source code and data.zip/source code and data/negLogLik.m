% negative log likelihood 
function out=negLogLik(a,b,q1,q2,clusters)
% matlab uses parameters k, theta

max_i=max(clusters);

% probability vector for model with these parameters
prob=generate_prob_vector(a,b,q1,q2,max_i);
        
out=-sum( log( prob(clusters) ));            
        
end


