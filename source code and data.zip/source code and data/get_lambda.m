
clear
%close all

load jurisdiction_data

map=jet(8);

% population of states in 100,000
state_pop{1}=290; state_pop{2}=215; state_pop{3}=117; state_pop{4}=128;
state_pop{5}=58; state_pop{6}=106; state_pop{7}=67; state_pop{8}=127;


% some stuff for dealing with dates
t1 = datetime(2020,01,10,8,0,0);
t2 = datetime(2020,12,25,8,0,0);
plot_dates = t1:t2;
pts=round(datenum(plot_dates));

% set dates for plot limits
tstart = datetime(2020,07,1);
tend = datetime(2020,12,1);


for j=1:numstates
    
%T=readtable(strcat('datasets/',name{dataset},'.xlsx'));
raw_dates=datenum(dates{j});
num_events{j}=length(raw_dates);
dat=raw_dates(~isnan(raw_dates));


[f{j},xi{j}]=ksdensity(dat,pts)
rate{j}=f{j}*num_events{j};

min(dat)
max(dat)

end

figure(24)
clf

colormap(map)
hold on
for k=1:numstates 
    
  plot(plot_dates,rate{k}/state_pop{k},'linewidth',3,'color',map(k,:))
end
legend(name,'location','northeast','fontsize',20)

ax = gca;
ax.FontSize = 16; 


xlim([tstart tend])

ylabel('exposures per day per 100,000 pop','fontname','sansserif','fontsize',20)
xlabel('date','fontname','sansserif','fontsize',20)
save us_lambda_data

print -dpng lambda_estimate


% read in US case count data

% get incidence over time for differen jurisdictions
  figure(25)
  clf
  hold on
  T=readtable('datasets/us-case-data-oct17.csv');
  shortname{1}='TX'; shortname{2}='FL'; shortname{3}='OH'; shortname{4}='PA'; shortname{5}='WI';
shortname{6}='GA'; shortname{7}='IA';  shortname{8}='IL';
numstates=length(shortname);
  for j=1:numstates
     
      stateTable=T(strcmp(T.state,shortname{j}),:);
      % sort dates
      [~,sortdate]=sort(stateTable.date);
      dates{j}=stateTable.date(sortdate); 
      cases{j}=smooth(stateTable.cases(sortdate),14);
      plot(dates{j},smooth(cases{j},14)/state_pop{j},'linewidth',3,'color',map(j,:))
      
      
  end
  

xlim([tstart tend])

ax = gca;
ax.FontSize = 16; 


ylabel('daily incident cases per 100,000 pop','fontname','sansserif','fontsize',20)
xlabel('date','fontname','sansserif','fontsize',20)

grid on



print -dpng incident_cases_us

