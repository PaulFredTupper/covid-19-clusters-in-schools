% run all the files for paper
clear 
close all


read_in_data_canada_final % figure 1

plot_theor_dist % figure 2 3

fit_models_canada % figure 4

get_lambda_canada % figure 5 6, 12

make_dispersion_plots % figure 7 8 

plot_beta_distribution % figure 9

explore_eventR % figure 10 , 11

% US stuff
run_me_usa % figs 21 through 24

q_sensitivity_analysis % figure 13


