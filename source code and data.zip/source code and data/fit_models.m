



clear

% load data
load jurisdiction_data



map=jet(8);


figure(23)
  
 

  colormap(map)
  hold on

xlabel('mean = $R_c+1$','fontname','sansserif','fontsize',30,'interpreter','latex')
ylabel('dispersion = $k$','fontname','sansserif','fontsize',30,'interpreter','latex')



% do only individual based ascertainment
q1=0.75; q2=1;

numstates=8;

% for each jurisdiction
for j=1:numstates
  
  clusters=clust{j}; clusters=clusters(clusters<30);

 % fit parameters
  [aHat(j),bHat(j),LHat,Hess{j}]=optim_fit_model(clust{j},q1,q2);

  a=aHat(j); b=bHat(j);
  
  meanClust(j)=1+aHat(j)*bHat(j);
  kDispersion(j)=aHat(j);
  
  plot(meanClust(j),kDispersion(j),'.','color',map(j,:),'markersize',20);
  
end
    

legend(name,'autoupdate','off','location','northeast','fontsize',20)

drawnow
    
for j=1:numstates
    
  
  Jac=[ bHat(j) aHat(j); 1 0];
     
  h = error_ellipse(Jac*inv(Hess{j})*Jac',[1+aHat(j)*bHat(j) aHat(j)],'conf',0.95); 
h.MarkerFaceColor = [map(j,:)]; %4th value is undocumented: transparency
alpha(0.3)
h.Color = [map(j,:)];
h.LineWidth = 2; 
    
end


%title('US','fontname','sansserif','fontsize',15)

axis([0 16 0 0.5]) 
print -dpng mu_k

save fit_params aHat bHat q1 q2 Hess


