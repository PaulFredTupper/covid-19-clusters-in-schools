



clear

% load data
load canadian_jurisdiction_data


map = brewermap(length(name),'Dark2');




  figure(4)  
clf
  
  colormap(map)
  hold on



% do only individual based ascertainment
q1=0.75; q2=1;

% for each jurisdiction
for j=1:numstates

  
  clusters=clust{j}; 

 % fit parameters
  [aHat(j),bHat(j),LHat,Hess{j}]=optim_fit_model(clust{j},q1,q2);

  a=aHat(j); b=bHat(j); %q1=q1Hat(j); q2=q2Hat(j);
  
 
  meanClust(j)=1+aHat(j)*bHat(j);
  kDispersion(j)=aHat(j);
  
  plot(meanClust(j),kDispersion(j),'.','color',map(j,:),'markersize',20);
  
end
    
legend(longname,'autoupdate','off','location','northwest','fontsize',20)

drawnow
    
for j=1:numstates
    

  
  Jac=[ bHat(j) aHat(j); 1 0];
     
  h = error_ellipse(Jac*inv(Hess{j})*Jac',[1+aHat(j)*bHat(j) aHat(j)],'conf',0.95); 
h.MarkerFaceColor = [map(j,:)]; %4th value is undocumented: transparency
alpha(0.3)
h.Color = [map(j,:)];
h.LineWidth = 2; 
    
end

ax = gca;
ax.FontSize = 19; 



axis([0 3 0 0.8]) 



xlabel('mean = $R_c+1$','fontname','sansserif','fontsize',30,'interpreter','latex')
ylabel('dispersion = $k$','fontname','sansserif','fontsize',30,'interpreter','latex')


print -dpng mu_k_canada


save fit_params_canada aHat bHat q1 q2 Hess meanClust kDispersion longname



