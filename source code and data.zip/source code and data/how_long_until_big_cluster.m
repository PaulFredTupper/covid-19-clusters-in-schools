
clear
close all

% load data
load canadian_jurisdiction_data

% load fit parameters
load fit_params_canada

% get info about juridictions
T=readtable('datasets/jurisdiction_information');
rows_in_table=9:12;
num_clus=T.clusters_in_database(rows_in_table);
total_days=T.days_in_timespan(rows_in_table);
clus_per_day=num_clus./total_days;


map = brewermap(length(name),'Dark2');



jrange=1:4;

set(gca, 'FontName', 'sansserif')
ax = gca;
ax.FontSize = 16; 


max_clus=30;



figure(16)

hold on

for j=jrange
  
    a=aHat(j); b=bHat(j);
  
  % generate probability mass vector for these parameters
  prob=generate_prob_vector(a,b,q1,q2,max_clus);
  
  sumprob=cumsum(prob,1,'reverse'); % sum up tail of prob distribution
  
  % waiting time
 
  waiting_time=1./(sumprob.*clus_per_day(j));
  
  plot(waiting_time,1:length(sumprob),'linewidth',3,'color',map(j,:));
  
  
end

axis([0 1000 0 12])

ylabel('cluster size','fontsize',15)
xlabel('expected days to cluster of this size or larger','fontsize',15)

legend(name)

title('Length of time to wait until cluster of a given size in dataset.')

print -dpng how_long_until_canada



