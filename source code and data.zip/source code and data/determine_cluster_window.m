
maxbin=15;

for j=1:4
    
    cps=c_p_school{j};
  
    figure(10)
    subplot(2,2,j)
    histogram(cps)
   
    figure(11)
    subplot(2,2,j)
    
    hc=histcounts(cps,(0:maxbin))
    plot((1:maxbin-1),hc(2:end),'.-')
    hold on
    
    mu=mean(cps);
    
    func =@(x) x/(1-exp(-x)) - mu;
    
    lambda=fzero(func,1);
    
    z=(1:maxbin-1);
    pz= (lambda.^z)./factorial(z)*exp(-lambda)/(1-exp(-lambda))*sum(hc);
    plot(z, pz,'k')
   
    
end
    
    