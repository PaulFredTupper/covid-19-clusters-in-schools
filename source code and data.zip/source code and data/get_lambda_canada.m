
clear

load canadian_jurisdiction_data

name{1}='Manitoba'; name{2}='Saskatchewan'; name{3}='Ontario'; name{4}='Alberta';
numstates=length(name);

% population of provinces in 100,000
prov_pop{1}=13.7; prov_pop{2}=11.7; prov_pop{3}=145.7; prov_pop{4}=43.7;


map = brewermap(length(name),'Dark2');

% some stuff for dealing with dates 
t1 = datetime(2020,01,10); % 10- Jan-2020 to 21- Oct 2021
t2 = datetime(2021,10,21);
plot_dates = t1:t2;
pts=round(datenum(plot_dates));


% set dates for plot limits
tstart = datetime(2020,09,1);
tend = datetime(2021,07,1);

for j=1:numstates
    
raw_dates=datenum(dates{j});
num_events{j}=length(raw_dates); % total number of clusters
dat=raw_dates(~isnan(raw_dates)); % dates of clusters

[f{j},xi{j}]=ksdensity(dat,pts)
%newdat{j}=dat;
rate{j}=f{j}*num_events{j};

min(dat)
max(dat)

end

figure(5)
clf

colormap(map)
hold on
for k=1:numstates
  plot(plot_dates,rate{k}/prov_pop{k},'linewidth',3,'color',map(k,:))
end
legend(name,'location','northwest','fontsize',20)

ax = gca;
ax.FontSize = 16; 


xlim([tstart tend])
%datetick('x', 'mmm dd', 'keepticks')


ylabel('exposures per day per 100,000 pop','fontname','sansserif','fontsize',20)
xlabel('date','fontname','sansserif','fontsize',20)

save canada_lambda_data

grid on

print -dpng lambda_estimate_canada



% get incidence over time for differen jurisdictions
  figure(6)
  clf
  hold on
  T=readtable('datasets/canada-case-data-oct17.csv');
  shortname{1}='MB'; shortname{2}='SK'; shortname{3}='ON'; shortname{4}='AB'; 
numstates=length(shortname);
  for j=1:numstates
     
      stateTable=T(strcmp(T.shortProvince,shortname{j}),:);
      % sort dates
      [~,sortdate]=sort(stateTable.date);
      dates{j}=stateTable.date(sortdate); cases{j}=smooth(stateTable.cases(sortdate),14);
      plot(dates{j},cases{j}/prov_pop{j},'linewidth',3,'color',map(j,:))
      
      
  end
  

xlim([tstart tend])
%datetick('x', 'mmm dd', 'keepticks')

ax = gca;
ax.FontSize = 16; 


ylabel('daily incident cases per 100,000 pop','fontname','sansserif','fontsize',20)
xlabel('date','fontname','sansserif','fontsize',20)

grid on

print -dpng incident_cases_canada

% plot exposures per day versus daily incidence
figure(12)
clf
hold on
for j=1:numstates

    temp=0;
    
    ca=cases{j};
    ra=rate{j};
    % select interval from tstart to tend
    ca=ca(find(dates{j}==tstart):find(dates{j}==tend));
    ra=ra(find(plot_dates==tstart)+temp:find(plot_dates==tend)+temp);
    plot(ca,ra,'.','color',map(j,:),'markersize',20)

    % correlation between two time series
    C=corr([ca ra'])
    corr_series=C(2,1);
    text(3000,40-5*j,strcat('correlation= ',num2str(corr_series)),'fontsize',20,'color',map(j,:))

end
xlabel('daily incident cases','fontname','sansserif','fontsize',20)
ylabel('exposures per day','fontname','sansserif','fontsize',20)

legend(name,'location','northeast','fontsize',20)


ax = gca;
ax.FontSize = 16; 

grid on

print -dpng scatter_plot_canada


