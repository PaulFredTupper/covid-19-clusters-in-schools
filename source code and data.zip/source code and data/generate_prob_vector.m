% Y is number of new infections is Poisson(gamma) where gamma is Gamma(a=k,b=theta)
% X is binom(Y+1,q1)
% then it is censored with probabilty 1-(1-q2)^X
% output is vector where kth entry is Prob(X=k), k >= 1 
% a is shape for gamma dist, b is scale, q is ascertainment probability
function prob=generate_prob_vector(a,b,q1,q2,maxk)

% how big we have to go for Y depends on how big we go for X
if q1<0
    error('q1 cannot be less than zero')
end
if q2<0
    error('q2 cannot be zero')
end

maxi=round(maxk/q1*2);
  
% Y is negative binomial with params r,p
r=a;
p=b/(1+b);
% convert to q for matlab
q=1-p;
Yprob=nbinpdf((0:maxi),r,q);
% Yprob(i)=Prob(Y+1 = i)

prob=zeros(maxk,1);

% k is the value of X
for k=0:maxk
    % range of possible Y that could give X=k
    ivect=(max([k-1 0]):maxi);
    % prob X=k given Y=i
    probXgivenY=binopdf(k,ivect+1,q1);
    % prob that X is k
    prob(k+1)=sum( probXgivenY.*Yprob(ivect+1) );
end

% censor with probability 1-(1-q2)^X
prob=prob.*( 1 - (1-q2).^(0:maxk)' );
% omit the first term (meaning zero observed infections) and normalize to get probability
prob=prob(2:end)/sum(prob(2:end));


end
    

