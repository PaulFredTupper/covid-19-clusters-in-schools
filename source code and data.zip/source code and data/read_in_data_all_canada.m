

clear


figure(1)
clf



name{1}='MB'; name{2}='SK'; name{3}='ON'; name{4}='AB'; 

longname{1}='Manitoba'; longname{2}='Saskatchewan'; longname{3}='Ontario'; longname{4}='Alberta';

numstates=length(name);


number_clusters=zeros(numstates,1); % how many clusters in dataset, i.e. lines we use
number_schools=zeros(numstates,1); % number of schools appearing in cluster list
num_schools_mult_clusters=zeros(numstates,1); % number of schools with multiple clusters


% get cluster data
T=readtable('datasets/CanadaMap_QuebecMerge-210630.xlsx');
  
table_length=height(T);
  
  
  for j=1:numstates
  
      
     cluster_list=[];
  date_list=[];
  school_id_list=[]; 
     
    for k=1:table_length
      
      if strcmp(T.Province(k),name{j})
        line_cluster=T.Total_cases_to_date(k);
        z_cluster= textscan( line_cluster{:}, '%f', 'Delimiter',';' );
        z_cluster=z_cluster{:};
        line_clust_len=length(z_cluster);
        
        line_date=T.Date(k);
        z_date= textscan(line_date{:}, '%s', 'Delimiter',';');
        z_date=z_date{:};
        line_date_len=length(z_date);
        
        school_id=k;
      
        
        if ( line_clust_len >  line_date_len )
            % too many clusters, ignore extra ones
            z_cluster=z_cluster(1:line_date_len);
            disp('too many clusters')
        end
        if (line_clust_len < line_date_len)
            % too many dates, ignore extra ones
            z_date=z_date(1:line_clust_len);
            disp('too many dates')
        end
        
        cluster_list=[cluster_list; z_cluster];
        date_list=[date_list; z_date];
        school_id_list=[school_id_list; school_id*ones(length(z_cluster),1)];
        
        
      end

      
    end
  
    inds=(cluster_list>0 & cluster_list<50);
    cluster_list=cluster_list(inds);
    date_list=date_list(inds);
    school_id_list=school_id_list(inds);
    
  clust{j}=cluster_list;
  dates{j}=date_list;
  
  
  subplot(2,2,j)
  histogram(cluster_list,(0:30),'facecolor',[0.3010 0.7450 0.9330])
  hold on
  title(longname{j},'fontname','sansserif','fontsize',20)
  xlabel('cases per cluster','fontname','sansserif','fontsize',15)
  ylabel('count','fontname','sansserif','fontsize',20)
  xlim([0 30])
  
  % make dots for clusters of size 6 or larger
  for clussize=8:30
      num_with_size=sum(cluster_list==clussize);
      yl=ylim;
      scalefact=yl(2)/20;
      plot(clussize*ones(num_with_size),scalefact*(1:num_with_size),'.','markersize',20,'color',[0 0.4470 0.7410])
  end
  
  number_clusters(j)=length(cluster_list);
  number_schools(j)=length(unique(school_id_list));
  
  basic_week=week(datetime(date_list))-1; % minus one is to fix oddity of matlab
  % adjust so the last week of the year 2020 is 0
  cutoff=30;
  inds=basic_week>cutoff;
  basic_week(inds)=basic_week(inds)-52;
  
  
  tbl_week=crosstab(school_id_list,basic_week);

  num_schools_mult_clusters(j)=sum(sum(tbl_week')>1);
  
  
  frac_no_transm(j)=sum(cluster_list==1)/length(cluster_list);
  
  mean_obs_cluster(j)=mean(cluster_list);
  
  max_obs_cluster(j)=max(cluster_list);
  
  q3(j)=prctile(cluster_list,75);
  
  median_obs_cluster(j)=median(cluster_list);
  
  index_of_dispersion(j)=var(cluster_list)/mean(cluster_list);
  
  iod_without_index(j)=var(cluster_list-1)/mean(cluster_list-1);
  
  end
  
    
save canadian_jurisdiction_data


% print it out into latex table
for j=1:numstates
     disp(strcat(...
         longname{j},' &  ', ...
        num2str(number_clusters(j)),' & ',...
        num2str(number_schools(j)),' & ',...
         num2str(num_schools_mult_clusters(j)),' & ',...      
      num2str(num_schools_mult_clusters(j)/number_schools(j),'%.2f'),' \\'))
end
for j=1:numstates
     disp(strcat(...
         longname{j},' &  ', ...     
      num2str(frac_no_transm(j),'%.2f'),' & ',...
       num2str(mean_obs_cluster(j),'%.2f'),' & ',...
        num2str(max_obs_cluster(j)),' & ',...
        num2str(index_of_dispersion(j),'%.2f'),' & ',...
           num2str(iod_without_index(j),'%.2f'),' \\'))
end


  
for jjj=1:4
    subplot(2,2,jjj)
    ax = gca;
ax.FontSize = 16; 
end

print -dpng histograms_canada
