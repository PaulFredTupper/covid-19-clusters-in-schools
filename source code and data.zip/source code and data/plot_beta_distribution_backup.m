


figure(9)
clear
clf

% get Canadian data
load canadian_jurisdiction_data
load fit_params_canada


new_name{1}='MAN';
new_name{2}='SASK';
new_name{3}='ONT';
new_name{4}='ALB';


% sort in order of decreasing theta 
[~,ord]=sort(bHat,'descend');
[~,invord]=sort(ord);



T=12; % hours
n=25; % students in a class

num_states=length(name);

map = brewermap(length(name),'Dark2');
map= 0.5 + 0.5*map;


hold on 

p=[ .9 .99 .999 .9999 ];
%p=[ .9 .99 .999 .9999 ];

lil=0.1;

dark_grey=[0.1 0.1 0.1];

for k=1:num_states
    
    levs=gaminv(p,aHat(ord(k)),bHat(ord(k)));
    
    y=(0.3:0.03:levs(4));

    x=0.75*gampdf(y,aHat(ord(k)),bHat(ord(k)));
   
   inds=(1:length(x));
   patch(k+[x(inds) -fliplr(x(inds))  ],[y(inds) fliplr(y(inds)) ],map(k,:))
   alpha(0.8)
    
    for kk=1:length(p)
      plot([k-lil k+lil],[levs(kk) levs(kk)],'color',dark_grey,'linewidth',2)
      if k==1
          text(8.85,levs(kk),num2str(p(kk)),'HorizontalAlignment','right')
      end
    end

end

xlim([0.5 4.5])
ylim([-0.6 30])

xticks(1:12);
xticklabels({new_name{ord}});
xtickangle(0)

set(gca,'YColor',[0 0 0 ]);

ax = gca;
ax.FontSize = 19; 

ylabel('Poisson parameter \nu','fontname','sansserif','fontsize',30)


% put beta on the right axis
yyaxis right

ylim([-0.6 15]/300)



ylabel('transmission rate \beta, hours^{-1} ','fontname','sansserif','fontsize',30)

set(gca,'YColor',[0 0 0 ]);

print -dpng violin_creative_graph_canada


disp('\nu for Canadian provinces')
disp(' ')

disp(' \hline')


% values for nu 
for k=1:4
     levs=gaminv([0.5 0.9 0.99],aHat(ord(k)),bHat(ord(k)));
     
      a=aHat(ord(k)); b=bHat(ord(k));
     Jac=[ b a ; b/2/sqrt(a) sqrt(a) ];
     mat=Jac*inv(Hess{ord(k)})*Jac';
     mu=a*b;
     sigma=sqrt(a)*b;
     zval=1.960; % zvalues for 95% confidence interval
     
     disp(strcat(...
          name{ord(k)},' &  ', ...
         num2str(mu,'%5.2f'),' (',...
         num2str(mu-zval*mat(1,1),'%5.2f'),',',...
         num2str(mu+zval*mat(1,1),'%5.2f'),')',' & ',...
         num2str(sigma,'%5.2f'),' (',...
         num2str(sigma-zval*mat(2,2),'%5.2f'),',',...
         num2str(sigma+zval*mat(2,2),'%5.2f'),')',' \\'));
     
     
     
     

end

disp(' ')

disp(' \hline')

 
for k=1:4
     levs=gaminv([0.5 0.9 0.99],aHat(ord(k)),bHat(ord(k)));
     
      a=aHat(ord(k)); b=bHat(ord(k));
     Jac=[ b a ; b/2/sqrt(a) sqrt(a) ];
     mat=Jac*inv(Hess{ord(k)})*Jac';
     mu=a*b;
     sigma=sqrt(a)*b;
     zval=1.960; % zvalues for 95% confidence interval
     
     disp(strcat(...
          name{ord(k)},' &  ', ...
                num2str(levs(1),'%4.1e'),' &  ',...
         num2str(levs(2),'%5.1f'),' &  ',num2str(levs(3),'%5.1f'),' \\'));
     
     
     
     

end

disp(' ')

disp(' \hline')


% values for beta
disp('')
disp('values for beta Canada')
disp(' Jurisdiction & Mean & Standard Deviation \\ ')
disp(' \hline')
 for k=1:4
     levs=gaminv([0.5 0.9 0.99],aHat(ord(k)),bHat(ord(k))/(n*T));
    
      a=aHat(ord(k)); b=bHat(ord(k));
     Jac=[ b a ; b/2/sqrt(a) sqrt(a) ];
     mat=Jac*inv(Hess{ord(k)})*Jac';
     mat(1,1)=mat(1,1)/(n*T);
     mat(2,2)=mat(2,2)/(n*T);
     mu=a*b/(n*T);
     sigma=sqrt(a)*b/(n*T);
     zval=1.960; % zvalues for 95% confidence interval
     
     disp(strcat(...
          name{ord(k)},' &  ', ...
         num2str(mu,'%3.1e'),' (',...
         num2str(mu-zval*mat(1,1),'%3.1e'),',',...
         num2str(mu+zval*mat(1,1),'%3.1e'),')',' & ',...
         num2str(sigma,'%4.1e'),' (',...
         num2str(sigma-zval*mat(2,2),'%4.1e'),',',...
         num2str(sigma+zval*mat(2,2),'%4.1e'),')'))
 end
 
 disp(' ')
 disp(' Jurisdiction & Median & 90th percentile & 99th percentile \\ ')
disp(' \hline')
 for k=1:4
     levs=gaminv([0.5 0.9 0.99],aHat(ord(k)),bHat(ord(k))/(n*T));
    
      a=aHat(ord(k)); b=bHat(ord(k));
     Jac=[ b a ; b/2/sqrt(a) sqrt(a) ];
     mat=Jac*inv(Hess{ord(k)})*Jac';
     mat(1,1)=mat(1,1)/(n*T);
     mat(2,2)=mat(2,2)/(n*T);
     mu=a*b/(n*T);
     sigma=sqrt(a)*b/(n*T);
     zval=1.960; % zvalues for 95% confidence interval
     
     disp(strcat(...
          name{ord(k)},' &  ',...
                num2str(levs(1),'%4.1e'),' &  ',...
         num2str(levs(2),'%4.1e'),' &  ',num2str(levs(3),'%4.1e'),' \\'));
   
 end
