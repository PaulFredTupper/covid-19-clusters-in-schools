% make list of all clusters for R code that generates figure 1

diary list_of_all_clusters

clear
load jurisdiction_data

disp('country, jurisdiction, cases')

for jjj=1:8
    CC=clust{jjj};
    for jj=1:length(CC)
        disp(strcat(' US, ',name{jjj},' , ',num2str(CC(jj))))
    end
end

clear
load canadian_jurisdiction_data

for jjj=1:4
    CC=clust{jjj};
    for jj=1:length(CC)
        disp(strcat(' Canada, ',longname{jjj},' , ',num2str(CC(jj))))
    end
end


diary off

