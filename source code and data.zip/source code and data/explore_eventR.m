
% simulate three different types of intervention
clear


% file names
filename{1}='eventR_1'; filename{2}='eventR_2';

% values of R
Rvect=[1 2.5];
kvect=[0.4 0.4];
xMaxvect=[50 50];

for jjj=1:2

figure(9+jjj)
    
% select R and k

R=Rvect(jjj); k=kvect(jjj); xMax=xMaxvect(jjj);


% compute a and b. Adjustt to get parameters for beta by diving by class
% size and duration of exposure
a=k; b=R/k/25/12;

% adjust 

% number of clusters
num_clust=1e7;

% compute a bunch of beta
beta=gamrnd(a,b,num_clust,1);

%histogram(beta)

% generate a bunch of outbreaks in classrooms
class_size=25;
infect_time=12;
mixing_time=6;

inner_font_size=10;

he=num_clust^(1/4);
height1=he^3;
height2=he^2;
height3=he^1;
xpos=xMax*3/5;

% no intervention
p0=(1-exp(-beta*mixing_time));
Z0=binornd(class_size*infect_time/mixing_time,p0);
subplot(4,1,1)
histogram(Z0)
set(gca, 'YScale', 'log')
ylim([1 num_clust])

text(xpos,height1,'Baseline','fontsize',inner_font_size,'fontname','sansserif')
text(xpos,height2,strcat('mean second cases= ',num2str(mean(Z0),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')
text(xpos,height3,strcat('std second cases= ',num2str(std(Z0),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')
xlim([-0.5 xMax+0.5])

ax = gca;
ax.FontSize = 19; 

%ylabel('baseline','fontsize',10,'fontname','sansserif')
ylabel('Count','fontsize',19,'fontname','sansserif')


title(strcat('R_c= ',num2str(R),',  k=',num2str(k)),'fontsize',25,'fontname','sansserif')


% reducing beta
p1=(1-exp(-beta/2*mixing_time));
Z1=binornd(class_size*infect_time/mixing_time,p1);
subplot(4,1,2)
histogram(Z1)
set(gca, 'YScale', 'log')
ylim([1 num_clust])

text(xpos,height1,'Transmission Reduction','fontsize',inner_font_size,'fontname','sansserif')

text(xpos, height2,strcat('mean second cases= ',num2str(mean(Z1),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')
text(xpos,height3,strcat('std second cases= ',num2str(std(Z1),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')

xlim([-0.5 xMax+0.5])
ax = gca;
ax.FontSize = 19; 

ylabel('Count','fontsize',19,'fontname','sansserif')

%ylabel('reducing transmis','fontsize',10,'fontname','sansserif')

% reducing class_size
% no intervention
p2=(1-exp(-beta*mixing_time));
Z2=binornd(class_size/2*infect_time/mixing_time,p2);
subplot(4,1,3)
histogram(Z2)

set(gca, 'YScale', 'log')
ylim([1 num_clust])

text(xpos,height1,'Social Distancing','fontsize',inner_font_size,'fontname','sansserif')

text(xpos, height2,strcat('mean second cases= ',num2str(mean(Z2),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')
text(xpos,height3,strcat('std second cases= ',num2str(std(Z2),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')

ax = gca;
ax.FontSize = 19; 

xlim([-0.5 xMax+0.5])
ylabel('Count','fontsize',19,'fontname','sansserif')

%ylabel('smaller classes','fontsize',10,'fontname','sansserif')


% strict bubbling
p3=(1-exp(-beta*infect_time));
Z3=binornd(class_size,p3);
subplot(4,1,4)
histogram(Z3)

set(gca, 'YScale', 'log')
ylim([1 num_clust])

text(xpos, height2,strcat('mean second cases= ',num2str(mean(Z3),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')
text(xpos,height3,strcat('std second cases= ',num2str(std(Z3),'%4.2f')),'fontsize',inner_font_size,'fontname','sansserif')

xlim([-0.5 xMax+0.5])
text(xpos,height1,'Strict Bubbling','fontsize',inner_font_size,'fontname','sansserif')

ylabel('Count','fontsize',19,'fontname','sansserif')
%ylabel('strict bubbles','fontsize',10,'fontname','sansserif')
xlabel('Number of Secondary Cases','fontsize',20,'fontname','sansserif')

ax = gca;
ax.FontSize = 19; 

print(filename{jjj},'-dpng');

end

