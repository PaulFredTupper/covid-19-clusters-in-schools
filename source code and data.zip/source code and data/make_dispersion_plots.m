% make dispersion plots
clear


load fit_params_canada


% spacing of contour labels
labspac=450;

% explore R and k
Rvect=(0.1:0.01:2);
kvect=(0.01:0.002:0.6);

twenty_frac_secondary=zeros(length(kvect),length(Rvect));
twenty_frac_all=zeros(length(kvect),length(Rvect));


for jj=1:length(Rvect)
    R=Rvect(jj);
    for kk=1:length(kvect)
        k=kvect(kk);
    
        
         
         [twenty_frac_secondary(kk,jj),twenty_frac_all(kk,jj)]=nbinPareto(R,k);
         
    end
end


figure(7)
clf
contour(Rvect+1,fliplr(kvect),flipud(twenty_frac_secondary),'showtext','on','labelspacing',labspac)
%set(gca,'YDir','normal')
%colorbar

ax = gca;
ax.FontSize = 19; 

xlabel('Mean Cluster Size $R_c+1$','fontname','sansserif','interpreter','latex','fontsize',25)
ylabel('Dispersion $k$','fontname','sansserif','interpreter','latex','fontsize',25)

title('Fraction of Secondary Cases in 20% Largest Clusters','fontname','sansserif','fontsize',20)

hold on

label_offset=[ -0.1 0.02 ; -0.2 -0.02 ; -0.05 -0.02 ; -0.1 -0.02 ];

for j=1:4
    xx=meanClust(j); yy=kDispersion(j);
    plot(xx,yy,'k.','Markersize',15);
    text(xx+label_offset(j,1),yy+label_offset(j,2),longname{j})
end
% % manitoba
% plot(1.4392,0.3277,'k.','Markersize',15)
% text(1.45,0.34,'Manitoba')
% 
% % saskatchewan
% plot(1.5719,0.2844,'k.','Markersize',15)
% text(1.62,0.28,'Saskatchewan')
% 
% % alberta
% plot(1.6731,0.4527,'k.','Markersize',15)
% text(1.7,0.465,'Alberta')
% 
% % ontario
% plot(1.3109,0.3566,'k.','Markersize',15)
% text(1.20,0.345,'Ontario')



print -dpng contour_secondary

figure(8)
clf
contour(Rvect+1,fliplr(kvect),flipud(twenty_frac_all),'showtext','on','labelspacing',labspac)
%set(gca,'YDir','normal')
%colorbar

ax = gca;
ax.FontSize = 19; 

xlabel('Mean Cluster Size $R_c+1$','fontname','sansserif','interpreter','latex','fontsize',25)
ylabel('Dispersion $k$','fontname','sansserif','interpreter','latex','fontsize',25)

title('Fraction of All Cases in 20% Largest Clusters','fontname','sansserif','fontsize',20)


hold on


for j=1:4
    xx=meanClust(j); yy=kDispersion(j);
    plot(xx,yy,'k.','Markersize',15);
    text(xx+label_offset(j,1),yy+label_offset(j,2),longname{j})
end

print -dpng contour_all




