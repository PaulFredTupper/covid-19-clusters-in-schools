


clear

% load data
load canadian_jurisdiction_data


map = brewermap(length(name),'Dark2');

figure(13)


subplot(2,2,1)
colormap(map)
hold on
xlabel('$q_1$','fontname','sansserif','fontsize',20,'interpreter','latex')
ylabel('$R_c+1$','fontname','sansserif','fontsize',20,'interpreter','latex')
  

subplot(2,2,3)
colormap(map)
hold on
xlabel('$q_1$','fontname','sansserif','fontsize',20,'interpreter','latex')
ylabel('$k$ (dispersion)','fontname','sansserif','fontsize',20,'interpreter','latex')

subplot(2,2,2)
colormap(map)
hold on
xlabel('$q_2$','fontname','sansserif','fontsize',20,'interpreter','latex')
ylabel('$R_c+1$','fontname','sansserif','fontsize',20,'interpreter','latex')
  

subplot(2,2,4)
colormap(map)
hold on
xlabel('$q_2$','fontname','sansserif','fontsize',20,'interpreter','latex')
ylabel('$k$ (dispersion)','fontname','sansserif','fontsize',20,'interpreter','latex')






% do only individual based ascertainment
q1_vect=(0.2:0.1:1); q2=1;
%q1_vect=[0.75 1];

numstates=4;

aHat=zeros(numstates,length(q1_vect));
bHat=zeros(numstates,length(q1_vect));
mu=zeros(numstates,length(q1_vect));
disper=zeros(numstates,length(q1_vect));

% for each jurisdiction
for j=1:numstates

  clusters=clust{j}; 
    
  for kk=1:length(q1_vect)
  
    % fit parameters
    [aHat(j,kk),bHat(j,kk)]=optim_fit_model(clust{j},q1_vect(kk),q2);

     mu(j,kk)=1+aHat(j,kk)*bHat(j,kk);
     disper(j,kk)=aHat(j,kk);
      
  end
  
  subplot(2,2,1)
  plot(q1_vect,mu(j,:),'color',map(j,:),'linewidth',3)
   ylim([1 7])
  
  subplot(2,2,3)
  plot(q1_vect,disper(j,:),'color',map(j,:),'linewidth',3)
 ylim([0.2 .6])
  
  
  
end
   
subplot(2,2,1)
title('Individual Ascertainment Model','fontname','sansserif','fontsize',15)

legend(longname,'location','northeast','fontsize',10)



% do only individual based ascertainment
q1=0.75; q2_vect=(0.2:0.2:1);
%q1_vect=[0.75 1];

aHat=zeros(numstates,length(q2_vect));
bHat=zeros(numstates,length(q2_vect));
mu=zeros(numstates,length(q2_vect));
disper=zeros(numstates,length(q2_vect));

% for each jurisdiction
for j=1:numstates

  clusters=clust{j}; 
    
  for kk=1:length(q2_vect)
  
    % fit parameters
    [aHat(j,kk),bHat(j,kk)]=optim_fit_model(clust{j},q1,q2_vect(kk));

     mu(j,kk)=1+aHat(j,kk)*bHat(j,kk);
     disper(j,kk)=aHat(j,kk);
      
  end
  
  subplot(2,2,2)
  plot(q2_vect,mu(j,:),'color',map(j,:),'linewidth',3)
  ylim([1 3])
  
  
  subplot(2,2,4)
  plot(q2_vect,disper(j,:),'color',map(j,:),'linewidth',3)
  ylim([0.15 .6])
  
  
end


subplot(2,2,2)
title('Group Ascertainment Model','fontname','sansserif','fontsize',15)




print -dpng sensitivity_canada

