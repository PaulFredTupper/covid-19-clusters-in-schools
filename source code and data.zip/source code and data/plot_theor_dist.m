% theoretical distributions for different mu and k

clear


figure(2)
clf

sizes=(1:10);

k_vect=[ 0.1 0.3 1];

q1=1; q2=1;

mu=2;

for jjj=1:3
    k=k_vect(jjj);
    
    a=k; b=(mu-1)/k;
    
    pr=generate_prob_vector(a,b,q1,q2,max(sizes));
    
    semilogy(sizes,pr,'.','markersize',20)
    hold on
    
    lab{jjj}=strcat('$k= $',num2str(k_vect(jjj)));
    
end

ax = gca;
ax.FontSize = 19; 

legend(lab,'location','northeast','fontsize',25,'interpreter','latex','fontname','sansserif')

title('$R_c+1= 2$','fontsize',30,'interpreter','latex')
%xlabel(5,1,'R_c+1= 1.5','fontsize',20,'interpreter','latex')

xlabel('cluster size','fontname','sansserif','fontsize',25)
ylabel('frequency','fontname','sansserif','fontsize',25)

print -dpng changing_k


figure(3)
clf

sizes=(1:10);

mu_vect=[ 2 3 4];

q1=1; q2=1;

k=0.3;

for jjj=1:3
    mu=mu_vect(jjj);
    
    a=k; b=(mu-1)/k;
    
    pr=generate_prob_vector(a,b,q1,q2,max(sizes));
    
    semilogy(sizes,pr,'.','markersize',20)
    hold on
    
    lab{jjj}=strcat('$R_c+1= $',num2str(mu_vect(jjj)));
    
end

ax = gca;
ax.FontSize = 19; 

legend(lab,'location','northeast','fontsize',25,'interpreter','latex','fontname','sansserif')

title('$k=0.3$','fontsize',30,'interpreter','latex')
%xlabel(5,1,'R_c+1= 1.5','fontsize',20,'interpreter','latex')

xlabel('cluster size','fontname','sansserif','fontsize',25)
ylabel('frequency','fontname','sansserif','fontsize',25)

print -dpng changing_mu

