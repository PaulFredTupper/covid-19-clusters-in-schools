% estimate a=k, b=theta, using maximum likelihood estimation 
% only one of q1 or q2 should be different from 1.
% LHat is value of negloglikelihood at the estimate
%function [aHat,bHat,LHat]=optim_fit_model(clusters,q1,q2)
function [aHat,bHat,LHat,Hess]=optim_fit_model(clusters,q1,q2)

[xHat,fvalHat,~,~,~,Hess]=fminunc(@obj,[.5 .5]);
aHat=xHat(1);
bHat=xHat(2);
LHat=fvalHat;


function out=obj(x)
% matlab uses parameters k, theta

a=x(1);
b=x(2);

out=negLogLik(a,b,q1,q2,clusters);

end
            
        
end


