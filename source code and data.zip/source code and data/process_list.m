function [new_cluster,new_date,cluster_id]=process_list(z_cluster,z_date)
% anything that happens within day_window days of each other gets put in
% the same cluster
% first date reported is the date that gets put in the list

day_window=7;

% convert dates to numbers
dates=datenum(z_date);

% figure out how to cluster things within day_window days

indx=1; % the position in the new list
new_cluster=[z_cluster(1)];
new_date{indx,1}=z_date{1};

% give each of the old clusters an id of the new cluster that they are in
cluster_id=ones(size(z_cluster));

for k=2:length(z_cluster)
    if (dates(k)-dates(k-1))>day_window % more than that many days different
       % create new entry
       indx=indx+1;
       new_cluster(indx,1)=z_cluster(k);
       new_date{indx,1}=z_date{k};
    else % add to current entry
       new_cluster(indx,1)=new_cluster(indx)+z_cluster(k);
    end    
    cluster_id(k)=indx;
end


end