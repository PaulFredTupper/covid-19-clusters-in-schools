% find what fraction cases are in biggest 20% of the clusters
function [frac_secondary,frac_all]= nbinPareto(R,k)

r=k;
p=r/(R+r);

portion=0.2; % we want top 20%

thresh=nbininv(1-portion,r,p);  % the clusters this size and smaller contain 80% of the cases

threshprob=nbincdf(thresh,r,p);

remainder=threshprob-(1-portion);


inds=0:100;

probvect=nbinpdf(inds,r,p);


mean_cases_secondary=sum(probvect.*inds);

mean_cases_bottom_portion=sum(probvect(1:thresh).*inds(1:thresh))+(probvect(thresh+1)-remainder)*thresh;

frac_secondary=(mean_cases_secondary-mean_cases_bottom_portion)/mean_cases_secondary;


mean_cases_all=sum(probvect.*inds)+1;

mean_cases_bottom_portion_all=sum(probvect(1:thresh).*(1:thresh))+(probvect(thresh+1)-remainder)*(thresh+1);

frac_all=(mean_cases_all-mean_cases_bottom_portion_all)/mean_cases_all;

end

